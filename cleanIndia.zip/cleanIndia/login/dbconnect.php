<?php
	$host = "localhost";
	$dbname = "cleanindia";
	$password = '';
	$user = "root";
	$conn = mysqli_connect($host,$user,$password,$dbname);
?>